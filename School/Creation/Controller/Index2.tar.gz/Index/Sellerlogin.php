<?php
 
namespace School\Creation\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use School\Creation\Model\SellerFactory;

use Magento\Framework\View\Result\PageFactory;

 
class Sellerlogin extends Action
{
    /**
     * @var \Tutorial\SimpleNews\Model\NewsFactory
     */
    protected $_modelNewsFactory;
 
    /**
     * @param Context $context
     * @param NewsFactory $modelNewsFactory
     */
    public function __construct(Context $context,SellerFactory $modelSellerFactory,PageFactory $pageFactory) {
        
        $this->_modelSellerFactory = $modelSellerFactory;
                                        $this->resultPageFactory = $pageFactory;

        parent::__construct($context);
    }
 
    public function execute()
    {
        /**
         * When Magento get your model, it will generate a Factory class
         * for your model at var/generaton folder and we can get your
         * model by this way
         */
        $seller_id = $this->getRequest()->getParam('seller_id');





        $seller_model = $this->_modelSellerFactory->create();

        $collection = $seller_model->getCollection()->addFieldToFilter('seller_id',$seller_id);
//                        $this->resultPageFactory = $pageFactory;

        
        if($collection->getSize() ==1)
        {

              return $resultRedirect->setPath('*/index/sellersuccess/*',array('id'=>$seller_id));
            
        }
        else
        {
            $this->messageManager->addError(
                             __('Please Enter Correct Seller ID'));
              return $resultRedirect->setPath('*/index/create');
        }

    }
}
