<?php
 
namespace School\Creation\Controller\Index;
 
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use School\Creation\Model\CreateFactory;
use Magento\Framework\View\Result\PageFactory;



 
class Schoollogin extends Action
{
    /**
     * @var \Tutorial\SimpleNews\Model\NewsFactory
     */
    protected $_modelNewsFactory;
 
    /**
     * @param Context $context
     * @param NewsFactory $modelNewsFactory
     */
    public function __construct(Context $context,CreateFactory $modelCreateFactory,PageFactory $pageFactory) {
        
        $this->_modelCreateFactory = $modelCreateFactory;
                $this->resultPageFactory = $pageFactory;

        parent::__construct($context);
    }
 
    public function execute()
    {
        /**
         * When Magento get your model, it will generate a Factory class
         * for your model at var/generaton folder and we can get your
         * model by this way
         */
        $school_id = $this->getRequest()->getParam('school_id');


        $school_model = $this->_modelCreateFactory->create();
               // $this->resultPageFactory = $pageFactory;


        $collection = $school_model->getCollection()->addFieldToFilter('school_id',$school_id);
     

        
if($collection->getSize() ==1)
{

    $this->_redirect('*/index/success/*',array('id'=>$school_id));
    return;
}
else
{
    $this->messageManager->addError(
                     __('Please Enter Correct School ID'));
    return $resultRedirect->setPath('*/index/create');

}

    }
}
